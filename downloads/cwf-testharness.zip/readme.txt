You must have Java (v6 minimum) installed on your computer.

1. Extract the cwf-testharness.jar file to a folder of your choice.
2. Run the following command in the same directory where you saved the app:  java -jar cwf-testharness.jar
3. Open your favorite browser and enter the following url:  http://localhost:8080/standalone

If you see the login screen, click Login using the default credentials.
You should now see the Test Harness screen.


Note: Java creates a hidden folder called ".extract" when running an application this way.
It does not remove this folder when the application terminates.  This may cause anomalous
behavior when attempting to run different standalone apps in the same parent folder.
It is a good idea to delete this hidden folder prior to running the application.