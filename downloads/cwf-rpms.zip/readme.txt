1. Install the KIDS build in a GOLDB instance.
2. Make sure TaskMan is running there.
3. Make sure the CIA broker is running there (STARTALL^CIANBLIS).
4. Assign the RGCW security keys to your login user.
5. Start the standalone web server as:  java -jar cwf-rpms-1.2.0.jar
6. In your browser go to http://localhost:8080/standalone

Note:

Broker settings are preconfigured as follows:

broker.server=localhost
broker.port=9300
broker.namespace=GOLDB

If you need to override these settings, you may specify them on the command line
in step 5 above.  For example,

java -jar cwf-rpms.jar -Dbroker.port=9302 -Dbroker.namespace=DEWDROP

Note: Java creates a hidden folder called ".extract" when running an application this way.
It does not remove this folder when the application terminates.  This may cause anomalous
behavior when attempting to run different standalone apps in the same parent folder.
It is a good idea to delete this hidden folder prior to running the application.